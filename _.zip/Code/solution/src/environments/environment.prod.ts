export const environment = {
  production: true,
  apiUrl: 'https://packt-angular-social-api.now.sh/api',
};
